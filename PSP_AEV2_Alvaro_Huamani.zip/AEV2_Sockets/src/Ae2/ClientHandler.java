package Ae2;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

/**
 * Clase que representa el manejador de clientes en el servidor de chat.
 */
public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private ArrayList<ClientHandler> clients;
    private BufferedReader reader;
    private PrintWriter writer;
    private String username;

    /**
     * Constructor de la clase ClientHandler.
     * @param clientSocket Socket del cliente.
     * @param clients Lista de manejadores de clientes.
     */
    public ClientHandler(Socket clientSocket, ArrayList<ClientHandler> clients) {
        this.clientSocket = clientSocket;
        this.clients = clients;
    }

    /**
     * Método principal que se ejecuta cuando se inicia el hilo del manejador de clientes.
     */
    @Override
    public void run() {
        try {
            // Configurar lectura y escritura de datos
            reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            writer = new PrintWriter(clientSocket.getOutputStream(), true);

            // Realizar autenticación
            if (authenticate()) {
                while (true) {
                    String message = receiveMessage();
                    if (message == null || message.equals("exit")) {
                    	
                        disconnect();
                        break;
                    }

                    processMessage(message);
                }
            } else {
                sendMessage("Error de autenticación. Desconectando...");
                disconnectWithoutAuthentication();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Este bloque se ejecutará cuando el hilo se cierre, ya sea de manera normal o abrupta
            disconnect();
        }
    }

    /**
     * Método para enviar un mensaje al cliente.
     * @param message Mensaje a enviar.
     */
    public void sendMessage(String message) {
        writer.println(message);
    }

    /**
     * Método para recibir un mensaje del cliente.
     * @return Mensaje recibido.
     * @throws IOException Si hay un error de lectura.
     */
    private String receiveMessage() throws IOException {
        try {
            return reader.readLine();
        } catch (SocketException e) {
            // Captura la excepción SocketException y maneja la desconexión del cliente
            disconnect();
            return null;
        }
    }

    /**
     * Método para realizar la autenticación del cliente.
     * @return `true` si la autenticación es exitosa, `false` en caso contrario.
     * @throws IOException Si hay un error de lectura o escritura.
     */
    private boolean authenticate() throws IOException {
        boolean authenticated = false;

        while (!authenticated) {
            sendMessage("Ingrese usuario y contraseña separados por ';'");
            String credentials = receiveMessage();
            String[] parts = credentials.split(";");
            
            if (parts.length == 2) {
                String username = parts[0];
                String password = parts[1];

                // Verificar las credenciales con el archivo de texto
                if (checkCredentials(username, password)) {
                    this.username = username;
                    authenticated = true;
                    sendMessage("¡Autenticación exitosa!");
                } else {
                    sendMessage("Error de autenticación. Vuelva a intentarlo.");
                }
            } else {
                sendMessage("Formato incorrecto. Vuelva a intentarlo.");
            }
        }

        return authenticated;
    }

    /**
     * Método para verificar las credenciales en el archivo de texto.
     * @param username Nombre de usuario.
     * @param password Contraseña.
     * @return `true` si las credenciales son correctas, `false` en caso contrario.
     */
    private boolean checkCredentials(String username, String password) {
        try (BufferedReader br = new BufferedReader(new FileReader("credenciales.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 2 && parts[0].equals(username) && parts[1].equals(password)) {
                    return true; // Credenciales correctas
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false; // Credenciales incorrectas
    }

    /**
     * Método para procesar el mensaje recibido.
     * @param message Mensaje recibido.
     */
    private void processMessage(String message) {
        if (message.equals("?")) {
            // Enviar lista de usuarios conectados
            sendUserList();
        } else if (message.startsWith("@")) {
            // Mensaje privado
            processPrivateMessage(message);
        } else if (!message.isEmpty()) {
            // Mensaje para todos
            broadcastMessage(message);
        }
    }
    
    /**
     * Método para transmitir un mensaje a todos los clientes conectados.
     * @param message Mensaje a transmitir.
     */
    private void broadcastMessage(String message) {
        for (ClientHandler client : clients) {
            client.sendMessage(getUsername() + ": " + message);
        }
    }
    
    /**
     * Método para enviar la lista de usuarios conectados al cliente.
     */
    private void sendUserList() {
        StringBuilder userList = new StringBuilder("Usuarios conectados:");
        for (ClientHandler client : clients) {
            userList.append(" ").append(client.getUsername());
        }
        sendMessage(userList.toString());
    }
    
    /**
     * Método para procesar un mensaje privado y enviarlo al destinatario.
     * @param message Mensaje privado.
     */
    private void processPrivateMessage(String message) {
        String[] parts = message.split(" ", 2);
        if (parts.length == 2) {
            String recipientUsername = parts[0].substring(1); // Elimina el "@" del nombre de usuario
            String privateMessage = parts[1];

            for (ClientHandler client : clients) {
                if (client.getUsername().equals(recipientUsername)) {
                    client.sendMessage(getUsername() + ": " + privateMessage);
                    return;
                }
            }

            sendMessage("El usuario " + recipientUsername + " no está conectado.");
        }
    }

    /**
     * Método para desconectar el cliente.
     */
    private void disconnect() {
        if (clients.remove(this)) {
            try {
                // Enviar mensaje de desconexión al cliente
                sendMessage("Te has desconectado. ¡Esperamos volver a verte pronto!");
                // Cerrar el socket después de enviar el mensaje
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Client disconnected: " + clientSocket);
        }
    }


    /**
     * Método para manejar la desconexión sin autenticación.
     */
    private void disconnectWithoutAuthentication() {
        clients.remove(this);
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Client disconnected (authentication failed): " + clientSocket);
    }

    /**
     * Método para obtener el nombre de usuario del cliente.
     * @return Nombre de usuario del cliente.
     */
    public String getUsername() {
        return username;
    }
}
